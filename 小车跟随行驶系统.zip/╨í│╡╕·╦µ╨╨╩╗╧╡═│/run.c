/*
 * run.c
 *
 *  Created on: 2023��7��11��
 *      Author: 31782
 */
#include <msp430.h>
#include "pwm.h"
#include "uart1.h"
#include "uart0.h"
#include "key.h"
/*
 * P3.0,P3.1Ϊ����
 * P3.2,P3.3Ϊ����
*/

float s_err,s_old_err,speed_left,speed_right,k_p,k_d;

void pid(void)
{
    k_p=data1/1000;
    k_d=data2/1000;
    s_err = coordinate - 160;
    speed_left = (2 + (k_p*s_err + k_d*(s_err - s_old_err)))*100;
    speed_right = (2 - (k_p*s_err + k_d*(s_err - s_old_err)))*100;
    s_old_err = s_err;
}

void car_Init(void)
{
    P3DIR |= BIT0 + BIT1 + BIT2 + BIT3;
}

void car_go(void)
{
    pwm(500,550);
    P3OUT |= BIT0;//�øߵ�ƽ
    P3OUT &= ~BIT1;//�õ͵�ƽ
    P3OUT |= BIT2;//�øߵ�ƽ
    P3OUT &= ~BIT3;//�õ͵�ƽ
    Delay_ms(100);
}

void car_left(void)
{
    P3OUT |= BIT1;//�øߵ�ƽ
    P3OUT &= ~BIT0;//�õ͵�ƽ
    P3OUT |= BIT2;//�øߵ�ƽ
    P3OUT &= ~BIT3;//�õ͵�ƽ
}

void car_right(void)
{
    P3OUT |= BIT0;//�øߵ�ƽ
    P3OUT &= ~BIT1;//�õ͵�ƽ
    P3OUT |= BIT3;//�øߵ�ƽ
    P3OUT &= ~BIT2;//�õ͵�ƽ
}

void car_back(void)
{
    pwm (500,500);
    P3OUT |= BIT1;//�øߵ�ƽ
    P3OUT &= ~BIT0;//�õ͵�ƽ
    P3OUT |= BIT3;//�øߵ�ƽ
    P3OUT &= ~BIT2;//�õ͵�ƽ
}

void car_stop(void)
{
    pwm(0,0);
    P3OUT &= ~BIT0;//�õ͵�ƽ
    P3OUT &= ~BIT1;//�õ͵�ƽ
    P3OUT &= ~BIT2;//�õ͵�ƽ
    P3OUT &= ~BIT3;//�õ͵�ƽ

}

void car_lock(){

    car_back();
    Delay_ms(50);
    car_stop();
    flag = 0;
    Delay_ms(1500);
}
void xunxian(void){

    pwm(500*speed_left/200,550*speed_right/200);
    P3OUT |= BIT0;//�øߵ�ƽ
    P3OUT &= ~BIT1;//�õ͵�ƽ
    P3OUT |= BIT2;//�øߵ�ƽ
    P3OUT &= ~BIT3;//�õ͵�ƽ
}

