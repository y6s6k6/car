/*
 * key.h
 *
 *  Created on: 2023��7��11��
 *      Author: 31782
 */

#ifndef KEY_H_
#define KEY_H_

void Delay_ms(unsigned int milliseconds);
void key_Init();
void mode(void);
void key_mode();

#endif /* KEY_H_ */
