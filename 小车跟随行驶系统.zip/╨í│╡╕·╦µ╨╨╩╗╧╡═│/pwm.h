/*
 * pwm.h
 *
 *  Created on: 2023��7��11��
 *      Author: 31782
 */

#ifndef PWM_H_
#define PWM_H_

void pwm_Init();
void pwm (float p_l,float p_r);
void servo_Init();
void setServoAngle(int angle1 , int angle2);

#endif /* PWM_H_ */
