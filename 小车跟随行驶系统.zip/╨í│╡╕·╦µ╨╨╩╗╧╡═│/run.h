/*
 * run.h
 *
 *  Created on: 2023��7��11��
 *      Author: 31782
 */

#ifndef RUN_H_
#define RUN_H_

void car_Init(void);
void pid(void);
void car_go(void);
void xunxian(void);
void car_lock();
void car_left(void);
void car_right(void);
void car_back(void);
void car_stop(void);

#endif /* RUN_H_ */
