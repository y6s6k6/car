/*
 * uart3.h
 *
 *  Created on: 2023��7��30��
 *      Author: 31782
 */

#ifndef UART0_H_
#define UART0_H_

extern float data1;
extern float data2;
extern int receive0_flag;

void UART0_Init(void);
void receive0_hex();
int uart0_flag(void);
int Data_1(void);
int Data_2(void);
int Data_3(void);

#endif /* UART0_H_ */
